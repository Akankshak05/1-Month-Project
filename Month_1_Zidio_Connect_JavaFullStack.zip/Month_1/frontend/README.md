# Frontend - Month_1

React.js frontend skeleton for Month_1 of Zidio Connect.

Run instructions:
```
cd frontend
npm install
npm start
```
