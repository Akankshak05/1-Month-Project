// Placeholder React App for Month_1
function App() {
  return (<div><h1>Zidio Connect - Month_1</h1></div>);
}
export default App;