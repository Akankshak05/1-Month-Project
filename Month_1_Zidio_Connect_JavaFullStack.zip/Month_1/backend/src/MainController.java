// Sample placeholder Spring Boot controller for Month_1
public class MainController {
    // GET /api/ping -> returns pong
}
