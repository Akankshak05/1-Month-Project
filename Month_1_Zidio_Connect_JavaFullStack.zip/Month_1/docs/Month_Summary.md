Month 1 Summary:

- Project setup: Spring Boot project skeleton, React frontend skeleton, MySQL schema created.
- Implemented authentication module: registration and login APIs (placeholders).
- Created initial frontend pages: Login, Signup.
- Added README and run instructions.
